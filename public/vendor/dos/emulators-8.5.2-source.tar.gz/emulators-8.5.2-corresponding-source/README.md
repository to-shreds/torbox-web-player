# Source for emulators 8.5.2 browser DOSBox distribution

The corresponding source for `emulators.js`, `wdosbox.js`, `wdosbox.wasm`, `wlibzip.js` and `wlibzip.wasm` is supplied in this archive. Exact upstream identities and checksums are in SOURCE-PROVENANCE.json. The original GPL version 2 is in `emulators/LICENSE`; third-party license texts and notices are in THIRD-PARTY-NOTICES.txt and their source files.

## Contents

- `emulators/`: upstream API, worker/protocol glue, native DOSBox adapter, build scripts, exact expanded DOSBox gitlink, libzip and SDL_net.
- `emulators.js.map`: original published map with 83 source texts and one synthetic generated bundle entry. All real source texts match the source snapshot and exact embedded npm dependency packages, apart from generated src/build.ts as described below.
- `bundled-js-dependencies/`: source and MIT notices for core-js 3.30.0, browser-pack 6.1.0 and process 0.11.10. Versions come from upstream yarn.lock and match the published source map.
- `zlib-1.3.1/`: exact upstream zlib port source selected by Emscripten 5.0.2; the source tar SHA-512 matches the port's pinned hash.
- `emscripten-5.0.2-zlib-port/`: Emscripten port definition, configured header and original SDK license text.

## Build the distributed subset

Use Node.js 22, Yarn, CMake 3.21 or newer, Ninja and an activated Emscripten SDK 5.0.2. These versions follow upstream's release CI, rather than its older Dockerfile. Obtain build tools through their official projects. All linked application and dependency source used by this subset is included here; the compiler and its standard runtime/system libraries come with Emscripten.

From the archive's emulators directory:

```sh
./vendor-build/build.sh
```

The added helper builds wdosbox/wlibzip with upstream settings, uses the original upstream JS bundling task, and appends the original upstream worker footer. It does not require unrelated DOSBox-X or Sokol submodules. It produces the five assets in `emulators/dist` plus normal symbols/source maps. Npm build-time packages are fetched from the versions and integrity values in the original yarn.lock. The zlib build port likewise retrieves the pinned official source; its source is included for inspection and replacement.

The helper's Bash/Node syntax and CMake source/target configuration were checked. A complete Emscripten rebuild was not executed in the delivery environment. No byte-for-byte reproducibility claim is made: upstream embeds generated build time/version data and may vary compiler output. `src/build.ts` is the actual generated source from the published npm source map; its older Git archive version is separately preserved. See SNAPSHOT-ADJUSTMENTS.md for the precise packaging changes.

## Upstream complete development build

The original CMakeLists, Gulp tasks, yarn.lock and release workflow are included unchanged. The full upstream development build also includes DOSBox-X, Sokol and other backends not distributed by this site. Reconstruct that broader tree using upstream git commit 6bbf0925d221a7304ea8e0dda1e89b8dc01569b2 and its pinned recursive submodules, then use upstream `yarn run gulp production`. Those extra backends are unnecessary for the supplied subset.

## Redistribution

This source archive and the adjacent GPL license and notices must remain freely accessible wherever the covered browser binaries are distributed. A third-party upstream link alone is not this distribution's source delivery. Preserve the included original notices. This archive provides same-location source access under GPLv2 section 3(a) and its final paragraph; it is not a promise to fulfill future source requests under section 3(b). If source or runtime changes, update the archive and its provenance together.
