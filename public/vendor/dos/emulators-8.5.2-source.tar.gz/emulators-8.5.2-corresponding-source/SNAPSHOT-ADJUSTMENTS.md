# Snapshot packaging adjustments

The runtime C/C++ and TypeScript sources are copied from the official upstream commits identified in SOURCE-PROVENANCE.json. DOSBox is expanded from its exact gitlink commit. The libzip and SDL_net source trees retain upstream contents and license headers.

The generated `emulators/src/build.ts` is copied from the official npm distribution's source map, which corresponds to the shipped 8.5.2 bundle. The commit archive contains an older generated 8.4.2 copy, preserved in `emulators/snapshot-original/build.ts`.

`emulators/vendor-build` is an added packaging helper dated 2026-10-13. It retains upstream compile/link settings and selects only wdosbox and wlibzip. Its JavaScript bundling step uses the original upstream `compileJs` task and the original worker footer. It omits unrelated DOSBox-X, native Sokol, benchmarks, game fixtures and their binaries. Those omissions do not remove source compiled into the five distributed runtime assets.

This package is source only. It contains no game executables, ROMs, copyrighted game fixtures, emulator WASM, or compiled npm runtime assets.
